package com.order.dao;


import com.order.entity.User;




public interface UserDao {

	public User login(String account,String password);
	public int UpdatePWD(String account,String opwd,String npwd);
	//�����û�������ID
	public int changeId(String username);
}
