package com.order.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.order.dao.UserDao;
import com.order.entity.User;
import com.order.util.DBUtil;

public class UserDaoImpl implements UserDao {
	DBUtil util;
	Connection conn;
	User user = null;

	public UserDaoImpl() {
		util = new DBUtil();
		conn = util.openConnection();
	}

	public User login(String account, String password) {
		// ��ѯSQL���
		String sql = " select id,account,password,name,permission,remark "
				+ " from usertbl " + " where account=? and password=? ";
		// System.out.println(account + "  " + password);
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, account);
			pstmt.setString(2, password);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				// ����û���Ϣ
				int id = rs.getInt(1);
				String name = rs.getString(4);
				int permission = rs.getInt(5);
				String remark = rs.getString(6);
				// ��װ�û���Ϣ
				User u = new User();

				u.setId(id);
				u.setAccount(account);
				u.setPassword(password);
				u.setName(name);
				u.setPermission(permission);
				u.setRemark(remark);

				return u;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}

	public static void main(String[] args) {
		UserDao dao = new UserDaoImpl();
		System.out.println(dao.changeId("login01"));
		// // User u = dao.login("login01", "123");
		// int rs = dao.UpdatePWD("login01", "123", "234");
		// System.out.println(rs);
	}

	public int UpdatePWD(String npwd, String account, String opwd) {
		// ��ѯSQL���
		String sql = " update usertbl set password = ? where account = ? and password = ?";
		// System.out.println(account + "  " + password);
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, npwd);
			pstmt.setString(2, account);
			pstmt.setString(3, opwd);

			// ִ�в�ѯ
			int rs = pstmt.executeUpdate();

			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	public int changeId(String username) {
		// ��ѯSQL���
		String sql = " select id from usertbl where account = ?";
		// System.out.println(account + "  " + password);
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, username);

			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			int a = 0;
			if (rs.next()) {
				a = rs.getInt("id");
			}
			return a;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

}
