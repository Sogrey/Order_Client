package com.order.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.order.dao.MenuDao;
import com.order.entity.Menu;
import com.order.entity.OrderDetail;
import com.order.util.DBUtil;

public class MenuDaoImpl implements MenuDao {
	DBUtil util;
	Connection conn;
	public  MenuDaoImpl(){
		util = new DBUtil();
		conn = util.openConnection();
	}
	public static void main(String[] args) {
		MenuDao md = new MenuDaoImpl();
		ArrayList<Menu> ar = md.QueryMenu(1);
		for(Menu menu : ar){
			System.out.println(menu.getId()+"  "+menu.getCategory()+"   "
					+menu.getMenuname()+"  "+menu.getPrice()+"  "+menu.getRemark());
		}
	}
	public ArrayList<Menu> QueryMenu(int num) {
		// ��ѯSQL���
		String sql = " select id,category,menuname,price,units,pic,remark from menutbl where version>=?";
		ArrayList<Menu> ar = new ArrayList<Menu>();
			// ���Ԥ�������
			PreparedStatement pstmt;
			try {
				pstmt = conn.prepareStatement(sql);
			    pstmt.setInt(1, num);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				// ����û���Ϣ
				int id = rs.getInt(1);
				String category = rs.getString(2);
				String menuname = rs.getString(3);
				int price = rs.getInt(4);
				String units=rs.getString(5);
				String pic = rs.getString(6);
				String remark = rs.getString(7);
				// ��װ�û���Ϣ
				Menu u = new Menu();

				u.setId(id);
				u.setCategory(category);
				u.setMenuname(menuname);
				u.setPrice(price);
				u.setPic(pic);
				u.setUnits(units);
				u.setRemark(remark);
				ar.add(u);
			}
			return ar;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				util.closeConn(conn);
			}	
		return null;
			
	}
}
