package com.order.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.order.dao.OrderDao;
import com.order.entity.Customer;
import com.order.entity.Menu;
import com.order.entity.Order;
import com.order.entity.OrderDetail;
import com.order.util.DBUtil;

public class OrderDaoImpl implements OrderDao {
	DBUtil util;
	Connection conn;

	public OrderDaoImpl() {
		util = new DBUtil();
		conn = util.openConnection();
	}

	public static void main(String[] args) {
		// Order order = new
		// Order(1,2,"2012111614502010000231","2012:11:16:14:50",120601,9,0,1,1,0,
		// "22222");
		// new OrderDaoImpl().addOrder(order);
		// OrderDetail o = new OrderDetail(1, 22, 23, 1, "1", "3");
		// new OrderDaoImpl().addOrderDetail(o);

		 ArrayList<OrderDetail> list1 = new OrderDaoImpl()
		 .queryOderDerail("2013021802523020000676");
		 for (OrderDetail a : list1) {
		 System.out.println(a.getMenuId() + "  " + a.getNum() + "    "
		 + a.getState());
		 }
		// //
		//
		// Order o = new OrderDaoImpl().QueryOrder(2);
		// if (o == null) {
		// System.out.println("�ѽ��㣬ok");
		// } else {
		// System.out.println("��������ʱ���뻻��");
		// }

		// Order o = new OrderDaoImpl().queryOrder(70);
		//
		// System.out.println(o.getStartprice());

		// int res = new OrderDaoImpl().updateStartprice("444.0", 71);
		
//		ArrayList<Order> list1=new OrderDaoImpl().queryOderDerail();
//		 for (Order a : list1) {
//				 System.out.println(a.getSerial());
//				 }
		
		

	}

	public int addOrder(Order order) {
		String sql = " insert into ordertbl(iduser,serial"
				+ ",orderTime,userId,tableId,isPay,startprice,remark) values(?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			// pstmt.setInt(1, order.getId());
			pstmt.setInt(1, order.getIduser());
			pstmt.setString(2, order.getSerial());
			pstmt.setString(3, order.getOrderTime());
			pstmt.setInt(4, order.getUserId());
			pstmt.setInt(5, order.getTableId());
			// pstmt.setInt(7, order.getPersonNum());
			pstmt.setInt(6, 0);
			pstmt.setString(7, order.getStartprice());
			pstmt.setString(8, order.getRemark());
			// ִ�в�ѯ
			int rs = pstmt.executeUpdate();

			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	public int addOrderDetail(OrderDetail orderDetil) {
		String sql = " insert into orederdetailtbl(orderid,menuid,num,remark,state) values(?,?,?,?,?)";

		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, orderDetil.getOrderId());
			pstmt.setInt(2, orderDetil.getMenuId());
			pstmt.setInt(3, orderDetil.getNum());
			pstmt.setString(4, orderDetil.getRemark());
			pstmt.setString(5, "0");
			// ִ�в�ѯ
			int rs = pstmt.executeUpdate();

			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	public ArrayList<OrderDetail> queryOderDerail(String serial) {
		String sql = "select menuId,num,state,remark from orederdetailtbl where orderid = (select id from ordertbl where serial = ?)";
		PreparedStatement pstmt;
		Statement st;

		ArrayList<OrderDetail> menuid = new ArrayList<OrderDetail>();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, serial);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				OrderDetail orderDetail = new OrderDetail();
				orderDetail.setMenuId(rs.getInt("menuId"));
				orderDetail.setNum(rs.getInt("num"));
				orderDetail.setState(rs.getString("state"));
				orderDetail.setRemark(rs.getString("remark"));
				menuid.add(orderDetail);
			}
			return menuid;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}
	
	
	public ArrayList<Order> queryOderDerail() {
		String sql = "select serial  from ordertbl where ispay=0 ";
		PreparedStatement pstmt;
		Statement st;

		ArrayList<Order> menuid = new ArrayList<Order>();
		try {
			pstmt = conn.prepareStatement(sql);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Order orderDetail = new Order();
				orderDetail.setSerial(rs.getString("serial"));
				menuid.add(orderDetail);
			}
			return menuid;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}

	public Order QueryOrder(int tableId) {
		String sql = "select ispay from ordertbl where tableId = ? ";
		// ArrayList<Order> order = new ArrayList<Order>();
		PreparedStatement pstmt;

		try {
			// ���Ԥ�������
			pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setInt(1, tableId);

			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			Order o = null;
			while (rs.next()) {
				o = new Order();
				int isPay = rs.getInt(1);
				o.setIsPay(isPay);
				if (isPay == 0) {
					return o;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}

		// try {
		// pstmt = conn.prepareStatement(sql);
		// pstmt.setString(1, tableId);
		// // ִ�в�ѯ
		// ResultSet rs = pstmt.executeQuery();
		// while(rs.next()){
		// Order orderDetail = new Order();
		// orderDetail.setTableId(rs.getInt("tableId"));
		// order.add(orderDetail);
		// }
		// //����true��˵�����������˿�
		// return true;
		// } catch (SQLException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } finally {
		// util.closeConn(conn);
		// }
		return null;
	}

	public Order queryOrder(int orderId) {
		String sql = "select startprice from ordertbl where id = ? ";
		// ArrayList<Order> order = new ArrayList<Order>();
		PreparedStatement pstmt;

		try {
			// ���Ԥ�������
			pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setInt(1, orderId);

			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			Order o = null;
			if (rs.next()) {
				o = new Order();
				int price = rs.getInt(1);
				o.setStartprice(String.valueOf(price));
				return o;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}

	public int updateStartprice(String startprice, int orderId) {
		// ��ѯSQL���
		String sql = " update ordertbl set startprice = ? where id=?";
		PreparedStatement pstmt;
		// System.out.println(account + "  " + password);
		try {
			// ���Ԥ�������
			pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, startprice);
			pstmt.setInt(2, orderId);

			// ִ�в�ѯ
			int rs = pstmt.executeUpdate();

			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	// �ڲ�̨ʱ��������ˮ�ʺ�ɾ�������Լ����¶����źͿ�ʼ�۸�
	public boolean byserialdeleteOrderid(int orderId, String startprice,
			String serial) {
		String sql = "update orederdetailtbl set orderId=?  where orderId=(select id from ordertbl where serial=?)";
		String sql2 = "update ordertbl set startprice=? where id=? ";
		String sql1 = "delete from ordertbl where serial=? limit 1";
		
		boolean flag = false;
		PreparedStatement pstmt;
		// System.out.println(account + "  " + password);
		try {
			// ���Ԥ�������
			pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setInt(1, orderId);

			System.out.println("serial-------------------------------------"
					+ serial);

			pstmt.setString(2, serial);

			// ִ�в�ѯ
			int rs1 = pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			pstmt.setString(1, startprice);
			pstmt.setInt(2, orderId);
			// ִ�в�ѯ
			int rs2 = pstmt.executeUpdate();

			// ���Ԥ�������
			pstmt = conn.prepareStatement(sql1);
			pstmt.setString(1, serial);

			// ִ�в�ѯ
			int rs3 = pstmt.executeUpdate();
			System.out
					.println(rs1 + "**********************************" + rs2+ "**********************************" + rs3);
			if (rs1 != 0 && rs2 == 1 && rs3 == 1) {
				flag = true;
			}

			return flag;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return flag;
	}

}
