package com.order.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.order.dao.UtilDao;
import com.order.util.DBUtil;

public class UtilDaoImpl implements UtilDao {
	DBUtil util;
	Connection conn;

	public UtilDaoImpl() {
		util = new DBUtil();
		conn = util.openConnection();
	}

	public static void main(String[] args) {
		// System.out.println(new
		// UtilDaoImpl().byserialfindid("2012111614502010202231"));
		// System.out.println(new
		// int res=new
		// UtilDaoImpl().byserialprice("2012121111291020000626",120601,
		// 0,"364.0");
		// System.out.println(res);
		// System.out.println(new UtilDaoImpl().bytablefindid(101));

		// System.out.println(new UtilDaoImpl().bytablenumfindserial(9));

		// String level = new UtilDaoImpl().byidfindLevel(8);
		// System.out.println(level);
		//
		// String price = new UtilDaoImpl().bylevelfindTotalprice(level,
		// "3200.0");
		// System.out.println(price);
		//
		// new UtilDaoImpl().bytotalpricefindConsumption("6500.0", "0", 4);
		//		
		// String getlevel=new UtilDaoImpl().byconsumptionpromoteLevel("300");
		// System.out.println(getlevel);
		
		String startprice=new UtilDaoImpl().byserialfindStartprice("2012121218201010000004");
		System.out.println(startprice);

	}

	public int byserialfindid(String serial) {
		String sql = "select id from ordertbl where serial = ?";
		PreparedStatement pstmt;
		int a = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, serial);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				a = rs.getInt("id");
			}
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	public int byserialprice(String serial, int userId, int idUser,
			String totalprice) {
		String sql = " update ordertbl  set totalprice = ? , idUser =? ,userId = ?,isPay = 1 where serial = ?";
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, totalprice);
			pstmt.setInt(2, idUser);
			pstmt.setInt(3, userId);
			pstmt.setString(4, serial);
			System.out.println("pstmt.executeUpdate()-------------"+pstmt.executeUpdate());
			// ִ�в�ѯ
			int rs = pstmt.executeUpdate();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	public int bytablefindid(int table) {
		String sql = "select id from tabletbl where num = ?";
		PreparedStatement pstmt;
		int a = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, table);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				a = rs.getInt("id");
			}
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	// ��������Id������ˮ�ʺ�
	public String bytablenumfindserial(int table) {
		System.out.println("11111");
		String sql = "select serial from ordertbl where tableid = ?";
		PreparedStatement pstmt;
		String a = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, table);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				a = rs.getString("serial");
			}
			System.out.println(a + "77777777777777");
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return a;
	}

	public String byidfindLevel(int id) {
		String sql = "select level from customer where id = ?";
		PreparedStatement pstmt;
		String a = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				a = rs.getString("level");
			}
			return a;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}

	public String bylevelfindTotalprice(String level, String totalprice) {
		double totalPrice = Double.parseDouble(totalprice);
		if (level.equals("ͭ��")) {

			totalPrice = totalPrice * 0.9;
		}
		if (level.equals("����")) {

			totalPrice = totalPrice * 0.8;
		}
		if (level.equals("����")) {

			totalPrice = totalPrice * 0.7;
		} else {
			totalPrice = totalPrice * 1;
		}
		totalprice = String.valueOf(totalPrice);
		return totalprice;
	}

	// ��Ա���Ѹ������ѽ�� nconsumption�����º��� oconsumption������ǰ��� customerId:�˿�id��
	public int bytotalpricefindConsumption(String nconsumption,
			String oconsumption, int customerId) {
		// ��ѯSQL���
		String sql = " update customer set consumption = ? where consumption=? and id=? ";
		String sql1 = "update customer set level=? where id=? ";
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, nconsumption);
			pstmt.setString(2, oconsumption);
			pstmt.setInt(3, customerId);

			// ִ�в�ѯ
			int rs = pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql1);

			double consumPtion = Double.parseDouble(nconsumption);
			if (0 <= consumPtion && consumPtion < 3000) {
				pstmt.setString(1, "��ͨ��Ա");
				pstmt.setInt(2, customerId);
			}
			if (3000 <= consumPtion && consumPtion < 6000) {
				pstmt.setString(1, "ͭ��");
				pstmt.setInt(2, customerId);
			}
			if (6000 <= consumPtion && consumPtion < 10000) {
				pstmt.setString(1, "����");
				pstmt.setInt(2, customerId);
			}
			if (10000 <= consumPtion) {
				pstmt.setString(1, "����");
				pstmt.setInt(2, customerId);
			}
			pstmt.executeUpdate();
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	public String byserialfindStartprice(String serial) {
		String sql="select startprice from ordertbl where serial=?";
		PreparedStatement pstmt;
		String startprice = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, serial);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				startprice = rs.getString("startprice");
			}
			return startprice;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return startprice;
	}

	public int byfindispay(String serial) {
		String sql = "select ispay from ordertbl where serial = ?";
		PreparedStatement pstmt;
		int res = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, serial);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				res = rs.getInt("ispay");
			}
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return res;
	}

}
