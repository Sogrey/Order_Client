package com.order.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.text.DefaultEditorKit.CutAction;

import com.order.dao.CustomerDao;
import com.order.dao.UserDao;
import com.order.entity.Customer;
import com.order.entity.User;
import com.order.util.DBUtil;

public class CustomerDaoImpl implements CustomerDao {
	DBUtil util;
	Connection conn;

	public CustomerDaoImpl() {
		util = new DBUtil();
		conn = util.openConnection();
	}

	public Customer login(String account, String pwd) {
		// ��ѯSQL���
		String sql = " select id,accout,pwd,name,phonenumber,gender,level,consumption "
				+ " from customer " + " where accout=? and pwd=? ";
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, account);
			pstmt.setString(2, pwd);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				// ����û���Ϣ
				int id = rs.getInt(1);
				String name = rs.getString(4);
				String phonenumber = rs.getString(5);
				String gender = rs.getString(6);
				String level = rs.getString(7);
				String consumption = rs.getString(8);
				// ��װ�û���Ϣ
				Customer u = new Customer();

				u.setId(id);
				u.setAccout(account);
				u.setPwd(pwd);
				u.setName(name);
				u.setPhonenumber(phonenumber);
				u.setGender(gender);
				u.setLevel(level);
				u.setConsumption(consumption);

				return u;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}

	public static void main(String[] args) {
		CustomerDao cut = new CustomerDaoImpl();
//		Customer cutomer = cut.login("timer", "123");
//		System.out.println(cutomer.getConsumption() + "  "
//				+ cutomer.getPhonenumber());
		Customer cutomer=cut.isFind("timer");
		String price=cutomer.getConsumption();
		System.out.println(price);
	}

	public int addCustomer(Customer customer) {
		// ��ѯSQL���
		String sql = " insert into Customer(accout,pwd,name,phonenumber,gender,date,level,consumption) "
				+ " values(?,?,?,?,?,?,?,?)";
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, customer.getAccout());
			pstmt.setString(2, customer.getPwd());
			pstmt.setString(3, customer.getName());
			pstmt.setString(4, customer.getPhonenumber());
			pstmt.setString(5, customer.getGender());
			pstmt.setString(6, customer.getDate());
			pstmt.setString(7, customer.getLevel());
			pstmt.setString(8, customer.getConsumption());
			// ִ�в�ѯ
			int rs = pstmt.executeUpdate();

			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return 0;
	}

	// �жϹ˿����Ƿ��Ѵ���
	public Customer isFind(String account) {
		// ��ѯSQL���
		String sql = " select * from Customer where accout = ?";
		// System.out.println(account + "  " + password);
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, account);

			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			Customer u =null;
			if (rs.next()) {
				String name = rs.getString(1);
				// ��װ�û���Ϣ
				u= new Customer();
				u.setAccout(name);
				return u;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}

	public int byaccoutfindId(String accout) {
		// ��ѯSQL���
		String sql = " select id from customer where accout = ?";
		// System.out.println(account + "  " + password);
		int a = 0;
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, accout);

			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				a = rs.getInt("id");
			}
			return a;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return a;
	}

	public String byaccoutfindconsumption(String accout) {
		// ��ѯSQL���
		String sql = " select consumption from customer where accout = ?";
		String consumption = null ;
		// System.out.println(account + "  " + password);
		try {
			// ���Ԥ�������
			PreparedStatement pstmt = conn.prepareStatement(sql);
			// ���ò�ѯ����
			pstmt.setString(1, accout);

			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				consumption = rs.getString("consumption");
			}
			return consumption;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return consumption;
	}

}
