/**
 * 
 */
package com.order.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.order.dao.CheckTableDao;
import com.order.dao.MenuDao;
import com.order.entity.CheckTable;
import com.order.entity.Menu;
import com.order.util.DBUtil;

/**
 * @author YZ-ZI
 * 
 */
public class CheckTableDaoImpl implements CheckTableDao {
	DBUtil util;
	Connection conn;

	public CheckTableDaoImpl() {
		util = new DBUtil();
		conn = util.openConnection();
	}

	public static void main(String[] args) {
		// CheckTableDao md = new CheckTableDaoImpl();
		// ArrayList<CheckTable> ar = md.QueryCheckTable();
		// for(CheckTable menu : ar){
		// System.out.println(menu.getId()+"  "+menu.getNum()+"   "
		//
		// +menu.getTablename()+"  "+menu.getNumber()+"  "+menu.getDescription());
		// // }
		// // System.out.println(new
		// CheckTableDaoImpl().changetable("2012111614502010000231", 3));
		// // System.out.println(new
		// CheckTableDaoImpl().setserial("2012111614502010000231",
		// "2012111614502010202231"));
		
		
int res=new CheckTableDaoImpl().changetable("2012121111291020000626", 2);
System.out.println(res);

//		String c=new CheckTableDaoImpl().bytableIdfindUsername(1);
//		System.out.println(c);
	}

	public ArrayList<CheckTable> QueryCheckTable(int num1) {
		// ��ѯSQL���
		// String sql =
		// " select id,num,tablename,number,description,flag from tabletbl where version >= ?";

		String sql = " select id,num,tablename,number,description from tabletbl where version >= ? ";
		ArrayList<CheckTable> ar = new ArrayList<CheckTable>();
		// ���Ԥ�������
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num1);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				// ���������Ϣ
				int id = rs.getInt(1);
				int num = rs.getInt(2);
				String tablename = rs.getString(3);
				String number = rs.getString(4);
				String description = rs.getString(5);
				// String flag=rs.getString(6);
				// ��װ������Ϣ
				CheckTable checktable = new CheckTable();
				checktable.setId(id);
				checktable.setNum(num);
				checktable.setTablename(tablename);
				checktable.setNumber(number);
				checktable.setDescription(description);
				// checktable.setFlag(flag);
				ar.add(checktable);
			}
			return ar;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;

	}

	public int changetable(String serial, int tablenum) {

		String sql = " update ordertbl  set tableId = ? where serial = ?";
		String sql1="";
		// ���Ԥ�������
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, tablenum);
			pstmt.setString(2, serial);
			int rs = pstmt.executeUpdate();
			pstmt=conn.prepareStatement(sql1);
			
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ִ�в�ѯ

		return 0;
	}

	public int setserial(String aserial, String bserial) {
		String sql = " update ordertbl  set serial = ? where serial = ?";
		// ���Ԥ�������
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bserial);
			pstmt.setString(2, aserial);
			int rs = pstmt.executeUpdate();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ִ�в�ѯ

		return 0;
	}

	public String bytableIdfindUsername(int tableId) {
		String sql = " select account from userTbl where id=(select userId from orderTbl where tableId=?)";
		ArrayList<CheckTable> ar = new ArrayList<CheckTable>();
		// ���Ԥ�������
		PreparedStatement pstmt;
		String account = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, tableId);
			// ִ�в�ѯ
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				// ���������Ϣ
				account = rs.getString("account");
			}
			return account;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.closeConn(conn);
		}
		return null;
	}

}
