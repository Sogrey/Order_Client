package com.order.dao;

import java.util.ArrayList;

import com.order.entity.Menu;

public interface MenuDao {
	//���²˵�
	public ArrayList<Menu> QueryMenu(int num);
}
