package com.order.entity;

public class OrderDetail {
	// ���
	private int id;
	// ����Id
	private int orderId;
	// ����Id
	private int menuId;
	// ����
	private int num;
	// ��ע
	//�˵�״̬
	private String state;
	
	private String remark;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public OrderDetail(int id, int orderId, int menuId, int num, String state,
			String remark) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.menuId = menuId;
		this.num = num;
		this.state = state;
		this.remark = remark;
	}
	public OrderDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
