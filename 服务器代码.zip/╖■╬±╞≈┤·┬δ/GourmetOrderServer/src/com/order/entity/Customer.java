package com.order.entity;


public class Customer {
	private int id;
	private String accout;
	private String pwd;
	private String name;
	private String phonenumber;
	private String gender;
	private String date;
	private String level;
	private String consumption;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccout() {
		return accout;
	}

	public void setAccout(String accout) {
		this.accout = accout;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getConsumption() {
		return consumption;
	}

	public void setConsumption(String consumption) {
		this.consumption = consumption;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Customer(int id, String accout, String pwd, String name,
			String phonenumber, String gender, String date, String level,
			String consumption) {
		super();
		this.id = id;
		this.accout = accout;
		this.pwd = pwd;
		this.name = name;
		this.phonenumber = phonenumber;
		this.gender = gender;
		this.date = date;
		this.level = level;
		this.consumption = consumption;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

}
