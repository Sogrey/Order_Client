package com.order.entity;

public class Order {
	// ���
	private int id;

	private int iduser;

	private String serial;
	// �µ�ʱ��
	private String orderTime;
	public String getStartprice() {
		return startprice;
	}

	public void setStartprice(String startprice) {
		this.startprice = startprice;
	}

	public String getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(String totalprice) {
		this.totalprice = totalprice;
	}

	// �µ��û�
	private int userId;
	// ����
	private int tableId;
	// ����
	private int personNum;
	// �Ƿ����
	private int isPay;
	// //Ԥ��۸�
	// private int startprice;
	// //����۸�
	// private int totalprice;

	// Ԥ��۸�
	private String startprice;
	// ����۸�
	private String totalprice;
	// ��ע
	private String remark;

//	public int getStartprice() {
//		return startprice;
//	}
//
//	public void setStartprice(int startprice) {
//		this.startprice = startprice;
//	}
//
//	public int getTotalprice() {
//		return totalprice;
//	}
//
//	public void setTotalprice(int totalprice) {
//		this.totalprice = totalprice;
//	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIduser() {
		return iduser;
	}

	public void setIduser(int iduser) {
		this.iduser = iduser;
	}

	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getTableId() {
		return tableId;
	}

	public void setTableId(int tableId) {
		this.tableId = tableId;
	}

	public int getPersonNum() {
		return personNum;
	}

	public void setPersonNum(int personNum) {
		this.personNum = personNum;
	}

	public int getIsPay() {
		return isPay;
	}

	public void setIsPay(int isPay) {
		this.isPay = isPay;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

//	public Order(int id, int iduser, String serial, String orderTime,
//			int userId, int tableId, int personNum, int isPay, int startprice,
//			int totalprice, String remark) {
//		super();
//		this.id = id;
//		this.iduser = iduser;
//		this.serial = serial;
//		this.orderTime = orderTime;
//		this.userId = userId;
//		this.tableId = tableId;
//		this.personNum = personNum;
//		this.isPay = isPay;
//		this.startprice = startprice;
//		this.totalprice = totalprice;
//		this.remark = remark;
//	}
	
	public Order(int id, int iduser, String serial, String orderTime,
			int userId, int tableId, int personNum, int isPay, String startprice,
			String totalprice, String remark) {
		super();
		this.id = id;
		this.iduser = iduser;
		this.serial = serial;
		this.orderTime = orderTime;
		this.userId = userId;
		this.tableId = tableId;
		this.personNum = personNum;
		this.isPay = isPay;
		this.startprice = startprice;
		this.totalprice = totalprice;
		this.remark = remark;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

}
