package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.order.dao.OrderDao;
import com.order.dao.Impl.OrderDaoImpl;
import com.order.entity.CheckTable;
import com.order.entity.OrderDetail;
/**
 * ��ѯ����
 * 
 * @author DaGang
 *
 */
public class QueryOreder extends HttpServlet {
	// ��ѯ����
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String orders = request.getParameter("orders");
//		String waiter = request.getParameter("waiter");
//		System.out.println(orders + "-------" + waiter);
		System.out.println(orders + "-------");
		OrderDao o = new OrderDaoImpl();
		ArrayList<OrderDetail> orderDetail = o.queryOderDerail(orders);
		JSONArray jsonarray = new JSONArray();
		ArrayList<String> order = null;
		JSONObject j = new JSONObject();
		for (OrderDetail t : orderDetail) {
			order = new ArrayList<String>();
			// username = check.bytableIdfindUsername(t.getId());
			System.out.println(t.getId() + "uuuuuuu");
			// table.add(username);
			order.add(String.valueOf(t.getMenuId()));
			System.out.println(String.valueOf(t.getMenuId()));
			order.add(String.valueOf(t.getState()));
			order.add(String.valueOf(t.getNum()));
			order.add(String.valueOf(t.getRemark()));
			// table.add(String.valueOf(t.getFlag()));
			if (orderDetail != null) {
				try {
					j.put("rt", "200");
					j.put("rtmsg", "������ѯ�ɹ�");
					jsonarray.put(order);
					j.put("list", jsonarray);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					j.put("rt", "21");
					j.put("rtmsg", "������ѯʧ��");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		out.print(j.toString());
		System.out.println(j.toString());
		out.flush();
		out.close();

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
