package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.order.dao.OrderDao;
import com.order.dao.UserDao;
import com.order.dao.UtilDao;
import com.order.dao.Impl.OrderDaoImpl;
import com.order.dao.Impl.UserDaoImpl;
import com.order.dao.Impl.UtilDaoImpl;
import com.order.entity.OrderDetail;
/**
 * 
 * @author DaGang
 *
 */
public class AddOrderServlet extends HttpServlet {
	// ���Ӷ������ؽ����Ϣ
	private int res;

	// �Ӷ���
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String list = request.getParameter("list");

		try {
			JSONObject json = new JSONObject(list);
			System.out.println(json.toString());

			ArrayList<Integer> b = new ArrayList<Integer>();

			// ������������ȡJSONArray����
			JSONArray listarray = json.getJSONArray("list");
			System.out.println(listarray.toString());
			for (int index = 0, length = listarray.length(); index < length; index++) {
				System.out.println(listarray.get(index));
			}

			addOrderDetail(json, listarray);
		} catch (JSONException e) {
			// out.print("û������");
			e.printStackTrace();
		}

		// UtilDao util = new UtilDaoImpl();
		// OrderDao orderDao = new OrderDaoImpl();
		// OrderDetail orderDetail = new OrderDetail();
		// JSONObject json = null;
		// try {
		//
		// String serial = json.getString("serial");
		// int orderId = util.byserialfindid(serial);
		// orderDetail.setOrderId(orderId);
		// ArrayList<String> list = (ArrayList<String>) json.get("list");
		// orderDetail.setMenuId(Integer.parseInt(list.get(0)));
		// orderDetail.setNum(Integer.parseInt(list.get(1)));
		// orderDetail.setRemark(list.get(2));
		// res = orderDao.addOrderDetail(orderDetail);
		// } catch (JSONException e) {
		// e.printStackTrace();
		// }
		JSONObject jsonobj = new JSONObject();
		System.out.println("----------" + res);
		if (res == 1) {
			try {
				jsonobj.put("rt", "200");
				jsonobj.put("rtmsg", "�ӵ��ɹ�");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			try {
				jsonobj.put("rt", "21");
				jsonobj.put("rtmsg", "�ӵ�ʧ��");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		out.print(jsonobj.toString());
		out.flush();
		out.close();
	}
	
	/**
	 *  ���Ӷ�������
	 *  
	 * @param json
	 * @param listarray
	 * @return
	 */
	private ArrayList<OrderDetail> addOrderDetail(JSONObject json,
			JSONArray listarray) {
		UserDao u = new UserDaoImpl();
		String orders;
		OrderDao orderDao=new OrderDaoImpl();
		try {
			orders = json.getString("orders");
			int orderId=new UtilDaoImpl().byserialfindid(orders);
			System.out.println(orderId+":id");
			String waiter = json.getString("waiter");
			int userId = u.changeId(waiter);
			String num = json.getString("sum");
			System.out.println("num+++++++++++++++++"+num);
			String price=orderDao.queryOrder(orderId).getStartprice();
			double startPrice=Double.parseDouble(num)+Double.parseDouble(price);
			orderDao=new OrderDaoImpl();
//			orderDao.queryOderDerail(orders);
			System.out.println(String.valueOf(startPrice)+"-----"+orderId);
			orderDao.updateStartprice(String.valueOf(startPrice), orderId);
			OrderDetail orderDetail = new OrderDetail();
			System.out.println("+++++" + "_______" + orders);
			ArrayList<OrderDetail> list = null;
			list = new ArrayList<OrderDetail>();
			// o.setMenuId((Integer.valueOf(json.getString(0))));
			// o.setNum((Integer.valueOf(json.getString(1))));
			// o.setState(json.getString(2));
			// Order o1 = new OrderDaoImpl().QueryOrder(tableId);

			for (int i = 0; i < listarray.length(); i++) {
				// System.out.println(json.get(i));
				String jsonStr = listarray.get(i).toString();
				System.out.println(jsonStr);
				JSONObject jsonObj = new JSONObject(jsonStr);
				jsonObj.get("list" + i);
				String str = jsonObj.get("list" + i).toString();
				System.out.println(str);

				String[] s = str.split(",");
				System.out.println("MenuId++++++" + Integer.valueOf(s[0])
						+ "-----" + s[2]);
				orderDetail.setOrderId(orderId);
				orderDetail.setMenuId(Integer.valueOf(s[0]));
				orderDetail.setNum(Integer.valueOf(s[1]));
				orderDetail.setRemark(s[2]);
				System.out.println(orderId + "+++++++orderId");
				orderDetail.setOrderId(orderId);
				list.add(orderDetail);
				res = new OrderDaoImpl().addOrderDetail(orderDetail);

			}
			return list;
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
