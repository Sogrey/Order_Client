package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.order.dao.OrderDao;
import com.order.dao.Impl.OrderDaoImpl;
import com.order.entity.CheckTable;
import com.order.entity.Order;
import com.order.entity.OrderDetail;

public class QueryAllOreder extends HttpServlet {
	boolean flag=true;
	// ��ѯ����
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		OrderDao o = new OrderDaoImpl();
		ArrayList<Order> orderDetail = o.queryOderDerail();
		JSONArray jsonarray = new JSONArray();
		ArrayList<String> order = null;
		JSONObject j = new JSONObject();
		if (orderDetail != null&&orderDetail.size()!=0) 
		{
			System.out.println("00000");
			for (Order t : orderDetail) 
			{
				System.out.println("yyyyy");
				if (t != null) 
				{
					System.out.println("11111");
					order = new ArrayList<String>();
					System.out.println();
					// username = check.bytableIdfindUsername(t.getId());
					System.out.println(t.getSerial() + "uuuuuuu");
					// table.add(username);
					order.add(String.valueOf(t.getSerial()));
					// table.add(String.valueOf(t.getFlag()));
						try {
							j.put("rt", "200");
							j.put("rtmsg", "�����Ų�ѯ�ɹ�");
							jsonarray.put(order);
							j.put("list", jsonarray);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else 
					{
						System.out.println("55555");
						try {
							j.put("rt", "21");
							j.put("rtmsg", "�����Ų�ѯʧ��");
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
			}
			}
				else {
					System.out.println("66666");
					try {
						j.put("rt", "21");
						j.put("rtmsg", "��δ���˶�����");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
		}
		out.print(j.toString());
		System.out.println(j.toString());
		out.flush();
		out.close();

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
