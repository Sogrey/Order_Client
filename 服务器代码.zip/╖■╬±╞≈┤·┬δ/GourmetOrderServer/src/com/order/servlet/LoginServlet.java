package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.order.dao.CustomerDao;
import com.order.dao.UserDao;
import com.order.dao.Impl.CustomerDaoImpl;
import com.order.dao.Impl.UserDaoImpl;
import com.order.entity.Customer;
import com.order.entity.User;


public class LoginServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("name");
		String password = request.getParameter("paw");
		System.out.println(username+"----------"+password);
		JSONObject json = new JSONObject();
		if(request.getParameter("category").equals("user")){
			UserDao dao = new UserDaoImpl();
			// ��ÿͻ����������
//			System.out.println(this.getServletContext().getRealPath("ss"));
			User u = dao.login(username, password);
			if(u!=null){
				try {
					json.put("rt", "200");
					json.put("rtmsg", "��¼�ɹ�");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				try {
					json.put("rt", "21");
					json.put("rtmsg", "�û��������������");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			out.print(json.toString());
		}else if(request.getParameter("category").equals("customer")){
			CustomerDao customer = new CustomerDaoImpl();
			Customer c = customer.login(username, password);
			if(c!=null){
				try {
					json.put("rt", "200");
					json.put("rtmsg", "��¼�ɹ�");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				try {
					json.put("rt", "21");
					json.put("rtmsg", "�û��������������");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			out.print(json.toString());
			System.out.println(json.toString());
		}
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//�޸�����
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String account=request.getParameter("name");
		String opwd = request.getParameter("opaw");
		String npwd = request.getParameter("npaw");
		System.out.println(request.getParameter("npaw")+"------"+request.getParameter("name")+"-------"+request.getParameter("opaw"));
		UserDao dao = new UserDaoImpl();
		int r = dao.UpdatePWD(npwd, account, opwd);
		JSONObject json = new JSONObject();
		if(r == 1){
			try {
//				System.out.println("---------------");
				json.put("rt", "200");
				json.put("rtmsg", "�޸�����ɹ�");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			try {
//				System.out.println("++++++++");
				json.put("rt", "21");
				json.put("rtmsg", "�޸�����ʧ��");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		out.print(json.toString());
		out.flush();
		out.close();
	}

}
