package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.order.dao.CheckTableDao;
import com.order.dao.MenuDao;
import com.order.dao.Impl.CheckTableDaoImpl;
import com.order.dao.Impl.MenuDaoImpl;
import com.order.entity.CheckTable;
import com.order.entity.Menu;
/**
 * ���·���
 * 
 * @author DaGang
 *
 */
public class UpdateServlet extends HttpServlet {

	// ���²˵� ����
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// System.out.println(request.getParameter("num"));
		// num �汾��
		String num = request.getParameter("num");

		JSONObject j = new JSONObject();
		// // ����JSONArray���飬����j���ӵ�����
		JSONArray array = new JSONArray();
		// System.out.println(Integer.parseInt(num));
		// System.out.println(request.getParameter("update"));
		if (request.getParameter("update").equals("menu")) {
			MenuDao menu = new MenuDaoImpl();
			ArrayList<Menu> m = menu.QueryMenu(Integer.parseInt(num));
			ArrayList<String> m1 = null;
			for (Menu m2 : m) {
				// System.out.println(m1);
				m1 = new ArrayList<String>();
				m1.add(String.valueOf(m2.getId()));
				m1.add(m2.getCategory());
				m1.add(m2.getMenuname());
				m1.add(m2.getPic());
				m1.add(String.valueOf(m2.getPrice()));
				m1.add(m2.getRemark());
				m1.add(m2.getUnits());
				// System.out.println(m2.getId()+m2.getPic()+m2.getCategory()+"-------");
				if (m != null) {
					try {
						j.put("rt", "200");
						j.put("rtmsg", Integer.parseInt(num));
						array.put(m1);
						j.put("list", array);

						// array.put(j);

					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					try {
						j.put("rt", "200");
						j.put("rtmsg", Integer.parseInt(num));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			// if (m != null) {
			// try {
			// j.put("rt", "200");
			// j.put("rtmsg", Integer.parseInt(num));
			// array.put(m1);
			// j.put("list", array);
			//
			// // array.put(j);
			//
			// } catch (JSONException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// } else {
			// try {
			// j.put("rt", "200");
			// j.put("rtmsg", Integer.parseInt(num));
			// } catch (JSONException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// }
			out.print(j.toString());
			System.out.println(j.toString());

		} else if (request.getParameter("update").equals("table")) {
			CheckTableDao check = new CheckTableDaoImpl();
			ArrayList<CheckTable> c = check.QueryCheckTable(Integer
					.parseInt(num));
//			String username = null;
			ArrayList<String> table = null;
			for (CheckTable t : c) {
				table = new ArrayList<String>();
//				username = check.bytableIdfindUsername(t.getId());
				System.out.println(t.getId() + "uuuuuuu");
//				table.add(username);
				table.add(String.valueOf(t.getNum()));
				table.add(String.valueOf(t.getTablename()));
				table.add(String.valueOf(t.getNumber()));
				table.add(String.valueOf(t.getDescription()));
				// table.add(String.valueOf(t.getFlag()));
				if (c != null) {
					try {
						j.put("rt", "200");
						j.put("rtmsg", Integer.parseInt(num));
						array.put(table);
						j.put("list", array);
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					try {
						j.put("rt", "200");
						j.put("rtmsg", Integer.parseInt(num));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				// if (c != null) {
				// try {
				// j.put("rt", "200");
				// j.put("rtmsg", Integer.parseInt(num));
				// j.put("list", c);
				// } catch (JSONException e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				// } else {
				// try {
				// j.put("rt", "200");
				// j.put("rtmsg", Integer.parseInt(num));
				// } catch (JSONException e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }

			}
			out.print(j.toString());
			System.out.println(j.toString());

		}

		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
