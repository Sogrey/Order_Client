package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.JsonObject;
import com.order.dao.OrderDao;
import com.order.dao.UserDao;
import com.order.dao.UtilDao;
import com.order.dao.Impl.CustomerDaoImpl;
import com.order.dao.Impl.OrderDaoImpl;
import com.order.dao.Impl.UserDaoImpl;
import com.order.dao.Impl.UtilDaoImpl;
import com.order.entity.Order;
import com.order.entity.OrderDetail;

public class OrderServlet extends HttpServlet {
	private int r;
	private int res;
	private String orders;
	private int tableId;
	private int tableNum;
	private Order o;

	// ����
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	// ���Ӷ�������
	public Order addOrder(JSONObject json) {
		Order order = new Order();

		try {
			UserDao u = new UserDaoImpl();
			orders = json.getString("orders");

			String name = json.getString("name");
			String cus = json.getString("cus");
			String status = json.getString("status");
			int cusId = new CustomerDaoImpl().byaccoutfindId(cus);
			String num = json.getString("sum");
			tableNum = Integer.parseInt(orders.substring(12, 15));
			tableId = new UtilDaoImpl().bytablefindid(tableNum);
			String orderTime = orders.substring(0, 11);
			int userId = u.changeId(name);
			o = new OrderDaoImpl().QueryOrder(tableId);
			if (o == null) {
				System.out.println(orders);
				System.out.println("orders" + orders);
				System.out.println("name" + name);
				order.setSerial(orders);
				order.setUserId(userId);
				order.setIduser(cusId);
				order.setRemark(status);
				order.setStartprice(num);
				order.setTableId(tableId);
				order.setOrderTime(orderTime);
				res = new OrderDaoImpl().addOrder(order);
				return order;

			} else {
				res = 0;
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	// ���Ӷ�����ϸ����Ϣ
	public ArrayList<OrderDetail> addOrderDetail(JSONArray json) {
		OrderDetail orderDetail = new OrderDetail();
		System.out.println(new OrderDaoImpl().QueryOrder(tableId) + "+++++"
				+ tableId + "_______" + orders);
		ArrayList<OrderDetail> list = null;
		try {
			list = new ArrayList<OrderDetail>();
			int orderId = new UtilDaoImpl().byserialfindid(orders);
			System.out.println(o);
			if (o == null && res == 1) {
				for (int i = 0; i < json.length(); i++) {
					 System.out.println(json.get(i));
					String jsonStr = json.get(i).toString();
					System.out.println(jsonStr);
					JSONObject jsonObj = new JSONObject(jsonStr);
					jsonObj.get("list" + i);
					String str = jsonObj.get("list" + i).toString();
					System.out.println(str);

					String[] s = str.split(",");
					System.out.println("MenuId++++++" + Integer.valueOf(s[0])
							+ "-----" + s[2]);
					orderDetail.setMenuId(Integer.valueOf(s[0]));
					orderDetail.setNum(Integer.valueOf(s[1]));
					orderDetail.setRemark(s[2]);
					// o.setState("0");

					// JsonObject jobj = (JsonObject) json.get(i);
					// System.out.println(jobj.get("list"));
					System.out.println(orderId + "+++++++orderId");
					orderDetail.setOrderId(orderId);
					list.add(orderDetail);
					r = new OrderDaoImpl().addOrderDetail(orderDetail);

				}
				return list;
			} else {
				r = 0;
			}

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// ArrayList<OrderDetail> list = null;
		// try {
		// list = (ArrayList<OrderDetail>) json.get(5);
		// } catch (JSONException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		return null;
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// System.out.println(request.getParameter("list"));
		// System.out.println(request.getParameter("orders"));
		// System.out.println(request.getParameter("name"));
		// System.out.println(request.getParameter("cus"));
		// System.out.println(request.getParameter("status"));
		// System.out.println(request.getParameter("sum"));
		// String orders = request.getParameter("orders");
		// String name = request.getParameter("name");
		// String cus = request.getParameter("cus");
		// String status = request.getParameter("status");
		// String sum = request.getParameter("sum");

		String list = request.getParameter("list");

		// UtilDao u = new UtilDaoImpl();
		try {
			JSONObject json = new JSONObject(list);
			// JSONObject json = new JSONObject();
			System.out.println(json.toString());

			// System.out.println("+++++");
			// System.out.println("json" + json);
			// OrderDao orderDao = new OrderDaoImpl();
			ArrayList<Integer> b = new ArrayList<Integer>();
			//
			addOrder(json);
			// System.out.println(order);
			// r = orderDao.addOrder(order);

			// ������������ȡJSONArray����
			JSONArray listarray = json.getJSONArray("list");
			System.out.println(listarray.toString());
			for (int index = 0, length = listarray.length(); index < length; index++) {
				// ������org.json.JSONArray�����о�Ȼû���ҵ�toArray���������λ���Ѹ�������취����
				System.out.println(listarray.get(index));
			}

			addOrderDetail(listarray);
			// for (OrderDetail d : orderDetil) {
			// // d.setOrderId(u.byserialfindid(array.getString(0)));
			// System.out.println(Integer.valueOf(listarray.getString(0)
			// + "---++++--" + Integer.valueOf(listarray.getString(1))
			// + "---+++++--" + listarray.getString(2)));
			// d.setMenuId(Integer.valueOf(listarray.getString(0)));
			// d.setNum(Integer.valueOf(listarray.getString(1)));
			// d.setState(listarray.getString(2));
			// res = orderDao.addOrderDetail(d);
			// b.add(res);
			//
			// }
		} catch (JSONException e) {
			// out.print("û������");
			e.printStackTrace();
		}
		JSONObject json = new JSONObject();
		System.out.println(r + "----------" + res);
		if (res == 1 && r == 1) {
			try {
				json.put("rt", "200");
				json.put("rtmsg", "���ӳɹ�");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			try {
				json.put("rt", "21");
				json.put("rtmsg", "����ʧ��");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		// if(res==1){
		// try {
		// json.put("rt", "200");
		// json.put("rtmsg", "������������ӳɹ�");
		// } catch (JSONException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// }else{
		// try {
		// json.put("rt", "21");
		// json.put("rtmsg", "�������������ʧ��");
		// } catch (JSONException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// }
		out.print(json.toString());
		out.flush();
		out.close();
	}

	// doGet(request, response);
	// System.out.println("--------------");
	// response.setContentType("text/html");
	// PrintWriter out = response.getWriter();
	// System.out.println(request.getParameter("list"));
	// System.out.println(request.getParameter("orders"));
	// System.out.println(request.getParameter("name"));
	// System.out.println(request.getParameter("cus"));
	// System.out.println(request.getParameter("status"));
	// System.out.println(request.getParameter("sum"));
	// String orders=request.getParameter("orders");
	// String name=request.getParameter("name");
	// String cus=request.getParameter("cus");
	// String status=request.getParameter("status");
	// String sum=request.getParameter("sum");
	//
	//
	// String orderarray = request.getParameter("list");
	//		
	// UtilDao u = new UtilDaoImpl();
	// try {
	// JSONArray array = new JSONArray(orderarray);
	// JSONObject json=new JSONObject();
	// json.put("orders", orders);
	// json.put("name", name);
	// json.put("cus", cus);
	// json.put("status", status);
	// json.put("sum", sum);
	// json.put("orders", orders);
	// json.put("array", array);
	// OrderDao orderDao = new OrderDaoImpl();
	// ArrayList<Integer> b = new ArrayList<Integer>();
	//
	// Order order = addOrder(array);
	// r = orderDao.addOrder(order);
	// ArrayList<OrderDetail> orderDetil = addOrderDetail(array);
	// for (OrderDetail d : orderDetil) {
	// d.setOrderId(u.byserialfindid(array.getString(0)));
	// res = orderDao.addOrderDetail(d);
	// b.add(res);
	//			
	//			
	// // orderDao.updateTableStatus(order.getTableId());
	// }
	// } catch (JSONException e) {
	// // out.print("û������");
	// e.printStackTrace();
	// }
	// JSONObject json = new JSONObject();
	// System.out.println(r+"----------");
	// if(res==1&&r==1){
	// try {
	// json.put("rt", "200");
	// json.put("rtmsg", "���ӳɹ�");
	// } catch (JSONException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }else{
	// try {
	// json.put("rt", "21");
	// json.put("rtmsg", "����ʧ��");
	// } catch (JSONException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// }
	// // if(res==1){
	// // try {
	// // json.put("rt", "200");
	// // json.put("rtmsg", "������������ӳɹ�");
	// // } catch (JSONException e) {
	// // // TODO Auto-generated catch block
	// // e.printStackTrace();
	// // }
	// // }else{
	// // try {
	// // json.put("rt", "21");
	// // json.put("rtmsg", "�������������ʧ��");
	// // } catch (JSONException e) {
	// // // TODO Auto-generated catch block
	// // e.printStackTrace();
	// // }
	// //
	// // }
	// out.print(json.toString());
	// out.flush();
	// out.close();
	// }

}
