package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.order.dao.CheckTableDao;
import com.order.dao.UserDao;
import com.order.dao.UtilDao;
import com.order.dao.Impl.CheckTableDaoImpl;
import com.order.dao.Impl.OrderDaoImpl;
import com.order.dao.Impl.UserDaoImpl;
import com.order.dao.Impl.UtilDaoImpl;
import com.order.entity.CheckTable;
import com.order.entity.User;

public class ChangetableServlet extends HttpServlet {
	// ת̨��������id
	int tablebId;
	// ��̨��������id
	int tableId;
	int res;
	boolean flag;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��̨
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String serial = request.getParameter("orders");
		String waiter = request.getParameter("waiter");
		System.out.println(serial+"------"+waiter);
		int table = Integer.parseInt(serial.substring(15, 18));
		int tableb = Integer.parseInt(serial.substring(12, 15));
		// ȡ��ˮ��
		UtilDao util = new UtilDaoImpl();
		System.out.println();
		tableId = util.bytablefindid(table);
		tablebId = new UtilDaoImpl().bytablefindid(tableb);
		System.out.println("tableId:-------" + tableId);
		System.out.println("tablebId:-------" + tablebId);
		String aserial = new UtilDaoImpl().bytablenumfindserial(tableId);
		String bserial = new UtilDaoImpl().bytablenumfindserial(tablebId);
		String startprice = new UtilDaoImpl().byserialfindStartprice(aserial);
		System.out.println("startprice-----------" + startprice);
		String startpriceb = new UtilDaoImpl().byserialfindStartprice(bserial);
		System.out.println("startpriceb-----------" + startpriceb);

		System.out.println("table:" + "---" + table);
		System.out.println("tableb:" + "---" + tableb);
		System.out.println("aserial:" + aserial);
		System.out.println("bserial:" + bserial);
		// ������ˮ��
		CheckTableDao check = new CheckTableDaoImpl();
		check.setserial(aserial, serial);

		// ��������
		String idcard = serial.substring(18, 19);
		System.out.println("idcard---------" + idcard);
		System.out.println("tablenum:" + tableb);

		System.out.println("serial:" + serial);
		if (idcard.equals("2")) {
			res = check.changetable(serial, tableId);

			int orderId = new UtilDaoImpl().byserialfindid(serial);
			System.out.println("orderId--------" + orderId);
			System.out.println(""
					+ (Double.parseDouble(startpriceb) + Double
							.parseDouble(startprice)));
			flag = new OrderDaoImpl().byserialdeleteOrderid(orderId, ""
					+ (Double.parseDouble(startpriceb) + Double
							.parseDouble(startprice)), bserial);
			System.out.println("flag------------" + flag);
		} else {
			res = check.changetable(serial, tablebId);
		}
		JSONObject json = new JSONObject();
		System.out.println(res);
		if (res == 1) {
			if (idcard.equals("1")) {
				try {
					json.put("rt", "200");
					json.put("rtmsg", "ת̨�ɹ�");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				if (idcard.equals("2") && flag == true)
					try {
						json.put("rt", "200");
						json.put("rtmsg", "��̨�ɹ�");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}

		} else {
			if (idcard.equals("1")) {
				try {
					json.put("rt", "21");
					json.put("rtmsg", "ת̨ʧ��");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					json.put("rt", "21");
					json.put("rtmsg", "��̨ʧ��");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		out.print(json.toString());
		System.out.println(json.toString());
		out.flush();
		out.close();
	}

	// public void doGet(HttpServletRequest request, HttpServletResponse
	// response)
	// throws ServletException, IOException {
	// // ��̨
	// response.setContentType("text/html");
	// PrintWriter out = response.getWriter();
	// String bserial = request.getParameter("orders");
	// System.out.println(bserial + "---++++++----");
	// String waiter = request.getParameter("waiter");
	// int table = Integer.parseInt(bserial.substring(16, 19));
	// // --------������
	// // ȡ��ˮ��
	// UtilDao util = new UtilDaoImpl();
	// String aserial = util.bytablenumfindserial(table);
	// // ������ˮ�Ų鶩��ID���ı�˵���ϸ����OrederID��
	// // //������ˮ��
	// // CheckTableDao check = new CheckTableDaoImpl();
	// // check.setserial(aserial, bserial);
	// // //��������
	// // int tablenum = Integer.parseInt(bserial.substring(12, 15));
	// // check.changetable(bserial, tablenum);
	//
	// // ----����
	// // ȡ��ˮ��
	// int table1 = Integer.parseInt(bserial.substring(12, 15));
	// String aserial1 = util.bytablenumfindserial(table1);
	// // ������ˮ��
	// CheckTableDao check = new CheckTableDaoImpl();
	// // System.out.println(tablenum);
	// System.out.println(bserial);
	// int res = check.setserial(aserial1, bserial);
	// JSONObject j = new JSONObject();
	// if (res == 1) {
	// try {
	// j.put("rt", "200");
	// j.put("rtmsg", "��̨�ɹ�");
	// } catch (JSONException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// } else {
	// try {
	// j.put("rt", "21");
	// j.put("rtmsg", "��̨ʧ��");
	// } catch (JSONException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	// out.print(j.toString());
	// out.flush();
	// out.close();
	//
	// }

}
