package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.JsonObject;
import com.order.dao.CustomerDao;
import com.order.dao.Impl.CustomerDaoImpl;
import com.order.entity.Customer;
/**
 * ע�᷽��
 * 
 * @author DaGang
 *
 */
public class RegisterServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String customer = request.getParameter("list");
		// System.out.println(customer+"     1111111111");
		Customer c = new Customer();
		JSONObject json = null;
		try {
			// JSONArray json = new JSONArray(customer);
			// JSONObject j = new JSONObject(customer);
			// JSONArray json = j.getJSONArray("list");
			JSONArray jsonarray = new JSONArray(customer);
			// ArrayList<String> json = (ArrayList<String>) j.get("list");
			// String customer1 = json.getString(0);
			// System.out.println(customer1+"           999999999");
			for (int i = 0; i < jsonarray.length(); i++) {
				System.out.println(jsonarray.get(i));
			}
			// for(int i=0;i<j.length();i++){
			// System.out.println(json.getString(i));
			// }
			String accout = (String) jsonarray.get(0);
			c.setAccout((String) jsonarray.get(0));
			CustomerDao cus = new CustomerDaoImpl();
			Customer c1 = cus.isFind(accout);
			json = new JSONObject();
			if (c1 == null) {

				c.setPwd((String) jsonarray.get(1));
				c.setName((String) jsonarray.get(0));
				c.setPhonenumber((String) jsonarray.get(4));
				c.setDate((String) jsonarray.get(3));
				c.setGender((String) jsonarray.get(2));
				c.setLevel("��ͨ��Ա");
				c.setConsumption("0");
				CustomerDao cdao = new CustomerDaoImpl();
				int res = cdao.addCustomer(c);

				if (res == 1) {
					try {
						json.put("rt", "200");
						json.put("rtmsg", "�˿�ע��ɹ�");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					try {
						json.put("rt", "21");
						json.put("rtmsg", "�˿�ע��ʧ��");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
			else
			{
				json.put("rt", "21");
				json.put("rtmsg", "ע�����Ѵ���");
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.print(json.toString());
		System.out.println(json.toString());
		out.flush();
		out.close();
	}

}
