package com.order.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.order.dao.UtilDao;
import com.order.dao.Impl.CustomerDaoImpl;
import com.order.dao.Impl.OrderDaoImpl;
import com.order.dao.Impl.UserDaoImpl;
import com.order.dao.Impl.UtilDaoImpl;

public class PayMoneyServlet extends HttpServlet {
	String totalprice;
	String startprice;

	// ����
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String orders = request.getParameter("orders");
		String waiter = request.getParameter("waiter");
		String cus = request.getParameter("cus");
		String sum = request.getParameter("sum");
		System.out.println(orders + "====" + waiter + "======cus:" + cus
				+ "=====sum:" + sum);
		// ArrayList<String> list = null;
		// try {
		// JSONObject json = new JSONObject();
		// list = (ArrayList<String>) json.get("arr");
		// } catch (JSONException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		UtilDao util = new UtilDaoImpl();
		int userId = new UserDaoImpl().changeId(waiter);
		int idUser = 0;
		int ispay = new UtilDaoImpl().byfindispay(orders);

		if (cus==null) {
			totalprice = sum;
			System.out.println("67676767");
		} else {
			idUser = new CustomerDaoImpl().byaccoutfindId(cus);
			System.out.println("idUser-------" + idUser);
			String level = new UtilDaoImpl().byidfindLevel(idUser);
			System.out.println("level--------" + level);
			if(level!=null)
			{
			totalprice = (new UtilDaoImpl().bylevelfindTotalprice(level, sum));
			totalprice=totalprice.substring(0,totalprice.indexOf("."));
			System.out.println("totalprice----------" + totalprice);
			startprice = new CustomerDaoImpl().byaccoutfindconsumption(cus);
			System.out.println("startprice:-----" + startprice);
			double Startprice = Double.parseDouble(startprice);
			double Totalprice = Double.parseDouble(totalprice);		
			String tprice = String.valueOf(Startprice + Totalprice);
			System.out.println("tprice--------" + tprice);
			if (ispay == 0) {
				int r = new UtilDaoImpl().bytotalpricefindConsumption(tprice,
						startprice, idUser);
				System.out.println("r:----" + r);
			}
			}
			else
			{
				totalprice = sum;
				System.out.println("yyyyyy");
			}
		}

		System.out.println("orders:" + orders + "----userId:" + userId
				+ "-----idUser:" + idUser + "----totalprice:" + totalprice
				+ "-----cus:" + cus);

		int res = util.byserialprice(orders, userId, idUser, totalprice);
		System.out.println(res);

		System.out.println("ispay----------" + ispay);
		JSONObject json = new JSONObject();
		if (res == 1) {
			if (ispay == 0) {
				try {
					json.put("rt", "200");
					json.put("rtmsg", "����ɹ�,���ۺ�۸�Ϊ" + totalprice);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					json.put("rt", "200");
					json.put("rtmsg", "Ǯ��û�ط����������ø���");
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

		} else {
			try {
				json.put("rt", "21");
				json.put("rtmsg", "����ʧ��");
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		System.out.println(json.toString());
		out.print(json.toString());
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
