/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50155
Source Host           : localhost:3306
Source Database       : gourmet_db

Target Server Type    : MYSQL
Target Server Version : 50155
File Encoding         : 65001

Date: 2013-12-16 18:16:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `accout` varchar(12) NOT NULL,
  `pwd` varchar(12) NOT NULL,
  `name` varchar(12) NOT NULL,
  `phonenumber` varchar(12) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `date` varchar(12) NOT NULL,
  `level` varchar(12) NOT NULL COMMENT '级别',
  `consumption` varchar(12) NOT NULL COMMENT '消费金额',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', 'timer', '123', '郭新新', '2147483647', '男', '2012-11-11', '银牌', '7438.6');
INSERT INTO `customer` VALUES ('3', 'dd', 'dd', 'dd', '11111', '男', '2012-11-11', '铜牌', '3311.0');
INSERT INTO `customer` VALUES ('4', 'dde', 'dd', 'dd', '11111', '男', '2012-11-11', '银牌', '6500.0');
INSERT INTO `customer` VALUES ('5', 'fff', 'ff', 'ffff', '111', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('6', 'hhd', 'ff', 'hhd', '111', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('7', 'hhd', 'ffr', 'hhd', '111', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('8', 'dddw', 'dd', 'dd', '111', '女', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('9', 'ddwd', 'dd', 'dd', '111', '女', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('10', 'ddff', 'dd', 'dd', '111', '女', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('11', 'ttff', 'hhh', 'tt', '22', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('12', 'sss', 's', 'sss', '2222', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('13', '1', '22', '1', '333', '男', '2012-11-11', '普通会员', '868.0');
INSERT INTO `customer` VALUES ('14', 'wqa', '2', 'wqa', '3', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('15', 'wywe', '123', 'wyw', '15210663247', '男', '1990-11-08', '普通会员', '0');
INSERT INTO `customer` VALUES ('16', 'wyw', 'www', 'wyw', '2', '男', '1990-11-08', '普通会员', '0');
INSERT INTO `customer` VALUES ('17', '123', '123', '123', '3', '男', '2012-11-28', '普通会员', '0');
INSERT INTO `customer` VALUES ('18', 'dddd', 'dd', 'dddd', '12', '男', '2012-10-29', '普通会员', '0');
INSERT INTO `customer` VALUES ('19', 'qz', '123', 'qz', '123', '男', '2012-11-30', '普通会员', '0');
INSERT INTO `customer` VALUES ('20', '1234', '1234', '1234', '123', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('21', '1235', '1235', '1235', '123', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('27', 'u', '8', 'u', '8888', '女', '2013-03-26', '普通会员', '0');
INSERT INTO `customer` VALUES ('22', 'ee', 'ee', 'ee', '13656783456', '男', '2012-08-03', '普通会员', '0');
INSERT INTO `customer` VALUES ('23', 'qq', 'qq', 'qq', '13745230569', '男', '2012-11-11', '普通会员', '0');
INSERT INTO `customer` VALUES ('24', 'ww', 'ww', 'ww', '13550670856', '男', '1996-10-02', '普通会员', '0');
INSERT INTO `customer` VALUES ('25', 'f', 'aa', 'f', '12378678777', '男', '2007-12-06', '普通会员', '0');
INSERT INTO `customer` VALUES ('26', 'xl', '12345678', 'xl', '12345678901', '女', '1991-09-06', '普通会员', '0');
INSERT INTO `customer` VALUES ('28', 'wb', '123', 'wb', '13754658978', '男', '1994-03-27', '普通会员', '0');

-- ----------------------------
-- Table structure for `menutbl`
-- ----------------------------
DROP TABLE IF EXISTS `menutbl`;
CREATE TABLE `menutbl` (
  `id` int(11) NOT NULL COMMENT '主键',
  `category` varchar(12) DEFAULT NULL COMMENT '类别',
  `menuname` varchar(50) DEFAULT NULL COMMENT '菜名称',
  `price` varchar(12) DEFAULT NULL COMMENT '价格',
  `units` varchar(12) NOT NULL COMMENT '单位（列/斤/两)',
  `pic` varchar(100) DEFAULT NULL COMMENT '图片路径',
  `version` varchar(6) NOT NULL,
  `remark` varchar(200) DEFAULT NULL COMMENT '介绍',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menutbl
-- ----------------------------
INSERT INTO `menutbl` VALUES ('1', '1201', '干煸豆角', '16', '0', 'images/hotdishes1.png', '1', '干煸是川菜中相当普遍的一种做法.是把食材用油慢慢煸干而衍生出一种特别的滑嫩腴香，清新爽口');
INSERT INTO `menutbl` VALUES ('2', '1201', '红烧金目鲈', '49', '0', 'images/hotdishes2.png', '1', '这是一道色泽好看，鱼质鲜嫩的家常菜。而且鲈鱼本身就有营养，味道鲜');
INSERT INTO `menutbl` VALUES ('3', '1201', '可乐鸡翅', '28', '0', 'images/hotdishes3.png', '1', '可乐鸡翅是一道常见的家常美味菜肴。有许多种做法，但主料均味鸡翅和可乐。其成菜味道鲜美，色泽艳丽，鸡翅嫩滑，又保留了可乐的香气');
INSERT INTO `menutbl` VALUES ('4', '1201', '麻婆豆腐', '11', '0', 'images/hotdishes4.png', '1', '豆腐的营养丰富，是家庭炒菜中广泛使用的材料。豆腐的做法很多，南北方各异，味道有清淡、有浓郁，亦可凉拌、烧煮、做汤');
INSERT INTO `menutbl` VALUES ('5', '1202', '双色皮冻', '16', '0', 'images/colddishes1.png', '1', '肉皮冻富含丰富的胶原蛋白，不但韧性好、口感佳，而且对人的皮肤、筋腱、骨骼、毛发都有重要的生理保健作用，物美价廉，美容养颜效果极好，是女士们不可多得的美容佳品。菠菜富含维生素 C、胡萝卜素、蛋白质，以及铁、钙、磷等矿物质。两者结合成双色的肉皮冻，再搭成魔方的形状，好吃又好看');
INSERT INTO `menutbl` VALUES ('6', '1202', '葱油金针菇', '12', '0', 'images/colddishes2.png', '1', '金针菇营养丰富。有益智的功效。这道葱油金针菇口感非常开胃爽口，是一道非常有代表性的凉菜');
INSERT INTO `menutbl` VALUES ('7', '1202', '挂糊咖喱虾', '30', '0', 'images/colddishes3.png', '1', '这是一个东南亚菜它的特色在于：黄红相间，浓香味醇。喜欢咖喱的朋友别错过');
INSERT INTO `menutbl` VALUES ('8', '1202', '卤猪肝', '20', '0', 'images/colddishes4.png', '1', '猪肝中铁质丰富，是补血食品中最常用的食物，食用猪肝可调节和改善贫血病人造血系统的生理功能；能保护眼睛，维持正常视力，防止眼睛干涩、疲劳，维持健康的肤色，对皮肤的健美具有重要意义；经常食用动物肝还能补充维生素B2，这对补充机体重要的辅酶，完成机体对一些有毒成分的去毒有重要作用；猪肝中还具有一般肉类食品不含的维生素Ｃ和微量元素硒，能增强人体的免疫反应，抗氧化，防衰老，并能抑制肿瘤细胞的产生，也可治急性');
INSERT INTO `menutbl` VALUES ('9', '1203', '胡萝卜玉米鲫鱼汤', '26', '0', 'images/soup1.png', '1', '这个汤，非常鲜甜好喝，加了赤小豆和眉豆，还有祛湿的效果');
INSERT INTO `menutbl` VALUES ('10', '1203', '肉片野菌羹', '25', '0', 'images/soup2.png', '1', '很鲜甜很惹味，加了莲藕粉，还具有清热的功效');
INSERT INTO `menutbl` VALUES ('11', '1203', '海带豆腐汤', '12', '0', 'images/soup3.png', '1', '简单，功效却不可小觑，它可以使清肠排毒变得事半功倍。味道清淡的豆腐与滋味鲜美的海带可谓相得益彰的绝配，注重健康的人，会视这道汤为长生不老的“妙药”');
INSERT INTO `menutbl` VALUES ('12', '1203', '马蹄银耳汤', '20', '0', 'images/soup4.png', '1', '荸荠是寒性食物，有清热泻火的良好功效。既可清热生津，又可补充营养，最宜用于发烧病人。它具有凉血解毒、利尿通便、化湿祛痰、消食除胀等功效。在呼吸道传染病流行季节，吃马蹄有利于流脑、麻疹、百日咳及急性咽喉炎的防治');
INSERT INTO `menutbl` VALUES ('13', '1204', '杏仁核桃露', '15', '0', 'images/drink1.png', '1', '可以迅速补充能量，又不会令人发胖，还有美容养颜的功效，特别适合爱美的女士');
INSERT INTO `menutbl` VALUES ('14', '1204', '可口可乐', '10', '0', 'images/drink2.png', '1', '可口可乐，来自美国，碳酸饮料，深受小朋友的喜爱');
INSERT INTO `menutbl` VALUES ('15', '1204', '柠檬薏米水', '14', '0', 'images/drink3.png', '1', '柠檬薏米水是款美白养颜的健康饮料，特别受年轻女士的喜爱，薏米有清热利尿、去水肿、排毒的功效，柠檬酸可防止和消除皮肤色素沉着，并有滋润美白肌肤的作用，还可以防止电脑辐射。这两者合二为一美白功效可见一斑。');
INSERT INTO `menutbl` VALUES ('16', '1204', '果粒橘汁', '10', '0', 'images/drink4.png', '1', '酸酸甜甜还有果粒的橘汁，既健康又经济');
INSERT INTO `menutbl` VALUES ('17', '1205', '米饭', '2', '0', 'images/staplefood1.png', '1', '米饭是一种主食，深受广大消费者的喜欢');
INSERT INTO `menutbl` VALUES ('18', '1205', '南瓜豆沙包', '12', '0', 'images/staplefood2.png', '1', '南瓜富含维生素、矿物质和纤维素，具有增强人体防癌、防心血管疾病、延缓衰老等功效，还可以除湿祛虫、退热止痢、补中益气、润肺安胎、对于糖尿病、高血压、肾脏病变及产妇缺乳、小儿百日咳等症也有辅助疗效');
INSERT INTO `menutbl` VALUES ('19', '1205', '炸酱面', '10', '0', 'images/staplefood3.png', '1', '面多，肉多，酱炸的香，每次一吃收不住嘴');
INSERT INTO `menutbl` VALUES ('20', '1205', '水煎包', '20', '0', 'images/staplefood4.png', '1', '皮喧底脆馅鲜。馅料嘛，荤的，素的，荤素搭配，水煎包馅料食材的种类多样化，这样可以让一种食物，涵盖多种营养，不仅味美，营养还全面');
INSERT INTO `menutbl` VALUES ('21', '1206', '碗筷', '1', '0', 'images/tableware1.png', '1', '中国人吃饭必备的餐具');

-- ----------------------------
-- Table structure for `ordertbl`
-- ----------------------------
DROP TABLE IF EXISTS `ordertbl`;
CREATE TABLE `ordertbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `idUser` int(6) NOT NULL COMMENT '顾客ID',
  `serial` varchar(25) NOT NULL COMMENT '流水号',
  `orderTime` varchar(30) DEFAULT NULL COMMENT '下单时间',
  `userID` int(11) DEFAULT NULL COMMENT '员工ID',
  `tableId` int(11) DEFAULT NULL COMMENT '桌号',
  `isPay` int(11) DEFAULT NULL COMMENT '是否结账',
  `startprice` varchar(12) DEFAULT NULL,
  `totalprice` varchar(12) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3408 DEFAULT CHARSET=utf8 COMMENT='订单表';

-- ----------------------------
-- Records of ordertbl
-- ----------------------------
INSERT INTO `ordertbl` VALUES ('1', '0', '', null, null, null, null, null, null, null);
INSERT INTO `ordertbl` VALUES ('3407', '1', '2013032804262010000892', '20130328042', '0', '5', '0', '50.0', null, '备注');
INSERT INTO `ordertbl` VALUES ('3406', '1', '2013040203062030000523', '20130402030', '0', '7', '0', '842.0', null, '备注');
INSERT INTO `ordertbl` VALUES ('3405', '1', '2013042103042020000106', '20130421030', '0', '6', '0', '120.0', null, '备注');
INSERT INTO `ordertbl` VALUES ('3404', '1', '2013032903031010000877', '20130329030', '0', '1', '0', '143.0', null, '备注');

-- ----------------------------
-- Table structure for `orederdetailtbl`
-- ----------------------------
DROP TABLE IF EXISTS `orederdetailtbl`;
CREATE TABLE `orederdetailtbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `orderId` int(11) DEFAULT NULL COMMENT '外键',
  `menuId` int(11) DEFAULT NULL COMMENT '外键',
  `num` int(11) DEFAULT NULL COMMENT '数量',
  `state` varchar(12) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=691 DEFAULT CHARSET=utf8 COMMENT='订单明细表';

-- ----------------------------
-- Records of orederdetailtbl
-- ----------------------------
INSERT INTO `orederdetailtbl` VALUES ('690', '3406', '18', '3', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('689', '3406', '21', '9', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('688', '3406', '17', '1', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('687', '3406', '4', '1', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('686', '3406', '1', '1', '0', ' 辣');
INSERT INTO `orederdetailtbl` VALUES ('685', '3406', '13', '1', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('684', '3406', '21', '1', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('683', '3406', '16', '1', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('682', '3406', '13', '1', '0', ' ');
INSERT INTO `orederdetailtbl` VALUES ('681', '3407', '8', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('680', '3407', '7', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('679', '3406', '11', '7', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('678', '3406', '1', '7', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('677', '3406', '3', '11', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('676', '3406', '21', '13', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('675', '3406', '8', '9', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('674', '3406', '7', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('673', '3405', '17', '8', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('672', '3405', '18', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('671', '3405', '20', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('670', '3405', '13', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('669', '3405', '12', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('668', '3405', '10', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('667', '3405', '6', '1', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('666', '3404', '21', '19', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('665', '3404', '14', '3', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('664', '3404', '1', '2', '0', 'la');
INSERT INTO `orederdetailtbl` VALUES ('663', '3404', '4', '2', '0', 'la');
INSERT INTO `orederdetailtbl` VALUES ('662', '3404', '6', '2', '0', '无备注');
INSERT INTO `orederdetailtbl` VALUES ('661', '3404', '5', '1', '0', 'liang');

-- ----------------------------
-- Table structure for `tabletbl`
-- ----------------------------
DROP TABLE IF EXISTS `tabletbl`;
CREATE TABLE `tabletbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `num` int(11) DEFAULT NULL COMMENT '桌号',
  `tablename` varchar(12) NOT NULL,
  `number` int(6) DEFAULT NULL COMMENT '人数',
  `description` varchar(100) DEFAULT NULL COMMENT '地址',
  `version` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tabletbl
-- ----------------------------
INSERT INTO `tabletbl` VALUES ('1', '101', '一楼1桌', '4', '包厢', '1');
INSERT INTO `tabletbl` VALUES ('2', '102', '一楼2桌', '6', '贵宾室', '1');
INSERT INTO `tabletbl` VALUES ('3', '103', '一楼3桌', '6', '普通桌', '1');
INSERT INTO `tabletbl` VALUES ('4', '104', '一楼4桌', '8', '普通桌', '1');
INSERT INTO `tabletbl` VALUES ('5', '201', '二楼1桌', '10', '贵宾室', '1');
INSERT INTO `tabletbl` VALUES ('6', '202', '二楼2桌', '6', '包厢', '1');
INSERT INTO `tabletbl` VALUES ('9', '301', '三楼1桌', '10', '包厢', '1');
INSERT INTO `tabletbl` VALUES ('8', '302', '三楼2桌', '20', '普通桌', '1');
INSERT INTO `tabletbl` VALUES ('7', '203', '二楼3桌', '12', '普通桌', '1');

-- ----------------------------
-- Table structure for `usertbl`
-- ----------------------------
DROP TABLE IF EXISTS `usertbl`;
CREATE TABLE `usertbl` (
  `id` int(11) NOT NULL COMMENT '主键',
  `account` varchar(20) DEFAULT NULL COMMENT '登陆账号',
  `password` varchar(20) DEFAULT NULL COMMENT '登录密码',
  `name` varchar(20) DEFAULT NULL COMMENT '姓名',
  `gender` varchar(20) DEFAULT NULL COMMENT '性别',
  `permission` int(11) DEFAULT NULL COMMENT '权限',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='系统用户表';

-- ----------------------------
-- Records of usertbl
-- ----------------------------
INSERT INTO `usertbl` VALUES ('120601', 'login01', '999999', 'login01', '女', '3', '服务员');
INSERT INTO `usertbl` VALUES ('120602', 'login02', '123456', 'login02', '男', '3', '服务员');
INSERT INTO `usertbl` VALUES ('120603', 'login03', '888888', 'login03', '女', '3', '服务员');
